
#pragma once

//=============================================================================
// StringLiteralSeq
//=============================================================================
class StringLiteralSeq
{
public:

	StringLiteralSeq()
	{
		mBeginCode = '\0';
	}

	bool isInStringLiteral() 
	{ 
		return ( mBeginCode != '\0' ); 
	}

	// TODO: \" ���l��
	void analyzeToken( const Base::TokenCode& token )
	{
		if ( token.Length == 1 ) 
		{
			if ( mBeginCode == '\0' &&
				 (*token.Begin == '"' || *token.Begin == '\'' ) ) 
			{
				mBeginCode = *token.Begin;
			}
			else if ( *token.Begin == mBeginCode ) 
			{
				mBeginCode = '\0';
			}
		}
	}

private:

	char	mBeginCode;
};

//=============================================================================
// AnnotationAnalyzer
//=============================================================================
class AnnotationAnalyzer
	: public Base::TokenAnalyzer
{
public:
};


//=============================================================================
// ArgmentListAnalyzer
//-----------------------------------------------------------------------------
//	(a,(v)b,c,d)
//	^ �ŏ��ɂ������w���Ă��邱��
//=============================================================================
class ArgmentListAnalyzer
	: public Base::TokenAnalyzer
{
public:

	enum OperatorType 
	{
		OT_LeftParen = 1,
		OT_RightParen,
		OT_Comma,
	};

public:

	int							mCurrentParenLevel;
	std::vector<const char*>	mArgBeginArray;		///< ( �܂��� , �̎�
	const char*					mArgListEnd;		///< ) �̂ЂƂO

public:

	ArgmentListAnalyzer()
	{
		mCurrentParenLevel = 0;
		mArgListEnd = NULL;
	}

	virtual const Base::OperatorCode* getOperatorList()
	{
		static const Base::OperatorCode codes[] = 
		{
			{ _T("("),  1, OT_LeftParen },
			{ _T(")"),	1, OT_RightParen },
			{ _T(","),  1, OT_Comma },
			{ NULL,     0, 0 }
		};
		return codes;
	}

	virtual const Base::KeywordCode* getKeywordList()
	{
		static const Base::KeywordCode codes[] = 
		{
			{ NULL,		0, 0 }
		};
		return codes;
	}

	virtual void analyzeToken( const Base::TokenCode& token )
	{
		if ( mArgListEnd != NULL ) return;

		//-----------------------------------------------------
		// ( ) �̃J�E���g
		if ( token.Type == Base::TOKEN_TYPE_OPERATOR ) {
			if ( token.UserType == OT_LeftParen ) {
				if ( mCurrentParenLevel == 0 ) {
					// �J�n
					mArgBeginArray.push_back( token.Begin + 1 );
				}
				++mCurrentParenLevel;
			}
			else if ( token.UserType == OT_RightParen ) {
				--mCurrentParenLevel;
				if ( mCurrentParenLevel == 0 ) {
					// �I��
					mArgListEnd = token.End - 1;
				}
			}
		}

		//-----------------------------------------------------
		// , ��T��
		if ( mCurrentParenLevel == 1 ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR ) {
				if ( token.UserType == OT_Comma ) {
					mArgBeginArray.push_back( token.Begin + 1 );
				}
			}
		}
	}
};