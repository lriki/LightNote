
#include "stdafx.h"
#include <vector>
#include <Core/Graphics/Device/LNFXManager.h>
#include "Utils.h"
#include "Converter.h"
#include "OutputFile.h"

//=============================================================================
// HSLSCompileExpressionAnalyzer
//=============================================================================
class HSLSCompileExpressionAnalyzer
	: public Base::TokenAnalyzer
{
public:

	enum OperatorType 
	{
		OT_LeftParen = 1,
		OT_RightParen,
	};

	enum KeywordType 
	{
		KT_Compile = 1,
	};

	enum SearchSeq
	{
		SearchSeq_FindCompile = 0,
		SearchSeq_FindShaderTarget,
		SearchSeq_FindFuncName,
		SearchSeq_FindLeftParen,
		SearchSeq_FindRightParen,
	};

public:

	SearchSeq	mSearchSeq;
	std::string	mFuncName;
	const char*	mArgListBegin;
	std::string	mArgList;

public:

	HSLSCompileExpressionAnalyzer()
	{
		mSearchSeq = SearchSeq_FindCompile;
		mArgListBegin = NULL;
	}

	virtual const Base::OperatorCode* getOperatorList()
	{
		static const Base::OperatorCode codes[] = 
		{
			{ _T("("),  1, OT_LeftParen },
			{ _T(")"),	1, OT_RightParen },
			{ NULL,     0, 0 }
		};
		return codes;
	}

	virtual const Base::KeywordCode* getKeywordList()
	{
		static const Base::KeywordCode codes[] = 
		{
			{ _T("compile"),	7, KT_Compile },
			{ NULL,				0, 0 }
		};
		return codes;
	}

	virtual void analyzeToken( const Base::TokenCode& token )
	{
		if ( mSearchSeq == SearchSeq_FindCompile ) {
			if ( token.Type == Base::TokenType_Keyword &&
				 token.UserType == KT_Compile ) {
				// �o�[�W������T���ɂ���
				mSearchSeq = SearchSeq_FindShaderTarget;
				return;
			}
		}
		else if ( mSearchSeq == SearchSeq_FindShaderTarget ) {
			if ( token.Type == Base::TOKEN_TYPE_IDENTIFIER ) {
				// ���O��T���ɂ���
				mSearchSeq = SearchSeq_FindFuncName;
				return;
			}
		}
		else if ( mSearchSeq == SearchSeq_FindFuncName ) {
			if ( token.Type == Base::TOKEN_TYPE_IDENTIFIER ) {
				// ���O�m��
				mFuncName = std::string( token.Begin, token.Length );
				// ( ��T���ɂ���
				mSearchSeq = SearchSeq_FindLeftParen;
				return;
			}
		}
		else if ( mSearchSeq == SearchSeq_FindLeftParen ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
				 token.UserType == OT_LeftParen ) {
				mArgListBegin = token.Begin + 1;
				// ) ��T���ɂ���
				mSearchSeq = SearchSeq_FindRightParen;
				return;
			}
		}
		else if ( mSearchSeq == SearchSeq_FindRightParen ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
				 token.UserType == OT_RightParen ) {
				// ���������X�g�m��
				mArgList = std::string( mArgListBegin, token.Begin - mArgListBegin );
				Base::StringUtil::deleteSpace( &mArgList );
				// �I��
				mSearchSeq = SearchSeq_FindCompile;
				return;
			}
		}
	}
};

//=============================================================================
// Converter
//=============================================================================

#define ARRAY_SIZE_OF( ary_ )     ( sizeof( ary_ ) / sizeof( ary_[ 0 ] ) )

	const lnChar* Converter::TmpFileName = _T("tmp");

	/// Pane �}�X�N�Ȃ��g�����W�V����
    const unsigned char BuiltInHLSL[] =
	{
		#include "../../LightNote/Source/Core/Resource/Shader/MMM_EffectHeader.fxh.h"
	};
    const unsigned int BuiltInHLSL_Size = ARRAY_SIZE_OF( BuiltInHLSL );

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	Converter::~Converter()
	{
		SAFE_RELEASE( mDxEffect );
	}	

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	bool Converter::convert( const char* filePath, DXDevice* device )
	{
		mFilePath = filePath;
		mDxDevice = device;
		mDxEffect = NULL;

		std::string tmpHLSLFileName = filePath;
		tmpHLSLFileName += ".tmp";

		//-----------------------------------------------------
		// �g�ݍ��� (�擪�� #include �ǉ�)

		Base::ReferenceBuffer* text = FileIO::File::readAllBytes( filePath );
		std::string orgHLSLText = std::string( (const lnChar*)text->getPointer(), text->getSize() );

		std::string newHLSLText = std::string( (const lnChar*)BuiltInHLSL/*, BuiltInHLSL_Size*/ );
		newHLSLText += "\n#line 1 \"";
		newHLSLText += filePath;
		newHLSLText += "\"\n";
		newHLSLText += orgHLSLText;
		FileIO::File::writeAllBytes( tmpHLSLFileName.c_str(), (const lnByte*)newHLSLText.c_str(), newHLSLText.size() );
		text->release();
		
		//printf("%s\n", newHLSLText.c_str());
		//printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n%s\n", orgHLSLText.c_str());
		//printf(newHLSLText.c_str());

		//-----------------------------------------------------
		// �R���p�C��

		LPD3DXBUFFER pShaderText;
		LPD3DXBUFFER pErrorMsgs = NULL;
		HRESULT hr = ::D3DXPreprocessShaderFromFile(
			tmpHLSLFileName.c_str(),
			NULL,
			NULL,
			&pShaderText,
			&pErrorMsgs );
		if ( FAILED( hr ) )
		{
			std::string errorMsg( (char*)pErrorMsgs->GetBufferPointer(), pErrorMsgs->GetBufferSize() );
			printf( "%s\n", errorMsg.c_str() );
			SAFE_RELEASE( pErrorMsgs );
			return false;
		}

		std::string input( (char*)pShaderText->GetBufferPointer(), pShaderText->GetBufferSize() );
		std::string preprocessHSLS = input;
		//printf(input.c_str());

		SAFE_RELEASE( pShaderText );
		SAFE_RELEASE( pErrorMsgs );

		Base::Parser parser;
		parser.analyze( input.c_str(), &mAnalyzer );

		// �R�[�h�ɏC��������O�� Effect �쐬
		ID3DXBuffer* errorBuf = NULL;
		hr = ::D3DXCreateEffect(
			mDxDevice->getDxDevice(),
			input.c_str(),
			input.size(),
			NULL,
			NULL,
			D3DXSHADER_ENABLE_BACKWARDS_COMPATIBILITY,
			NULL,
			&mDxEffect,
			&errorBuf );
		if ( FAILED( hr ) )
		{
			std::string errorMsg( (char*)errorBuf->GetBufferPointer(), errorBuf->GetBufferSize() );
			printf( "%s\n", errorMsg.c_str() );
			SAFE_RELEASE( errorBuf );
			return false;
		}


		// �T���v���^�ϐ��ƃe�N�X�`���^�ϐ��̑Ή��\�����
		mSamplerAttacher.analyze( mDxDevice->getDxDevice(), mDxEffect );


		//-----------------------------------------------------
		// technique {...} �̃X�e�[�g�����g�����ׂč폜����
		ln_foreach( HSLSTechniqueAnalyzer::TechniqueInfo& info, mAnalyzer.mTechniqueInfoArray )
		{
			for ( char* c = (char*)info.Begin; c <= info.End; ++c ) {
				if ( *c == '\r' || *c == '\n' ) {
					continue;
				}
				*c = ' ';
			}
		}
		//-----------------------------------------------------
		// �A�m�e�[�V���� (<...>) �����ׂč폜����
		ln_foreach( HSLSTechniqueAnalyzer::AnnotationInfo& info, mAnalyzer.mAnnotationInfoArray )
		{
			for ( char* c = (char*)info.Begin; c <= info.End; ++c ) {
				if ( *c == '\r' || *c == '\n' ) {
					continue;
				}
				*c = ' ';
			}
		}
		//-----------------------------------------------------
		// shared ������
		Base::StringUtil::replaceString( &input, "shared", "" );

		
		mInput = input;
		//-----------------------------------------------------
		// �G�N�X�|�[�g



		//-------------------------------------------------------------
		// ID3DXEffect ���� XML �쐬
        // �ϐ�
        D3DXHANDLE handle;
        UINT idx = 0;
        while ( true )
        {
            handle = mDxEffect->GetParameter( NULL, idx );
            if ( !handle ) break;
			mXMLDocument.InsertEndChild(
				_createVariableElement( handle ) );
			++idx;
        }

		// �e�N�j�b�N
		D3DXHANDLE tech = NULL;
        D3DXHANDLE next = NULL;
        do
        {
            mDxEffect->FindNextValidTechnique( tech, &next );
            if ( next )
            {
				mCurrentElementPath.clear();
				mXMLDocument.InsertEndChild(
					_createTechniqueElement( next ) );
            }
            tech = next;
        } while ( tech );

		//


		//-------------------------------------------------------------
		// �o��

		// �g���q�� .lnfx ��
		char drive[MAX_PATH] = { 0 };
		char dir[MAX_PATH] = { 0 };
		char filename[MAX_PATH] = { 0 };
		char ext[MAX_PATH] = { 0 };
		_splitpath( filePath, drive, dir, filename, ext );
		std::string newFilePath = drive;
		newFilePath += dir;
		newFilePath += filename;
		newFilePath += ".lnfx";

#if 1
		Graphics::LNFXManager lnfxManager;
		lnfxManager.openOutFile( newFilePath.c_str() );

		lnfxManager.writeHLSL( preprocessHSLS );
#else
		// XML�c���[�͈�x�o�͂��Ă���
		mXMLDocument.SaveFile( "output.tmp" );

		OutputFile outputFile;
		outputFile.open( newFilePath.c_str() );

		// HLSL
		outputFile.addHLSL( preprocessHSLS );

		// XML
		outputFile.addXMLFile( "output.tmp" );

		// GLSL
		ln_foreach( OutputShaderInfo& info, mOutputShaderInfoArray )
		{
			outputFile.addNamedText( info.ElementPath, info.ShaderOutput );
		}
#endif

		SAFE_RELEASE( mDxEffect );
		return true;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	XML::Element* Converter::_createVariableElement( D3DXHANDLE handle )
	{
		D3DXPARAMETER_DESC desc;
		mDxEffect->GetParameterDesc( handle, &desc );

		tinyxml2::XMLElement* element = mXMLDocument.NewElement("Variable");
		element->SetAttribute( "Name", desc.Name );
		element->SetAttribute( "Semantic", desc.Semantic ? desc.Semantic : "" );
		element->SetAttribute( "Shared", (desc.Flags & D3DX_PARAMETER_SHARED) != 0 );

		// �T���v���^�̏ꍇ�́A�֘A�t�����Ă���e�N�X�`���^�ϐ������i�[
		switch ( desc.Type )
		{
			case D3DXPT_SAMPLER:
			case D3DXPT_SAMPLER1D:
			case D3DXPT_SAMPLER2D:
			case D3DXPT_SAMPLER3D:
			case D3DXPT_SAMPLERCUBE:
			{
				const char* texName = mSamplerAttacher.getTextureNameBySampler( desc.Name );

				// ��`����Ă��邾���ŎQ�Ƃ���Ă��Ȃ��T���v���ϐ��̓e�N�X�`�������o�Ȃ��B
				// NULL �`�F�b�N���Ă����B
				if ( texName != NULL ) {
					element->SetAttribute( "Texture", texName );
				}
				
				break;
			}
			default:
				break;
		}

		// �A�m�e�[�V����
		for ( lnU32 i = 0; i < desc.Annotations; ++i )
        {
            D3DXHANDLE anno = mDxEffect->GetAnnotation( handle, i );
			XML::Element* child = _createAnnotationElement( anno );
			if ( child ) {
				element->InsertEndChild( child );
			}
		}

		return element;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	XML::Element* Converter::_createAnnotationElement( D3DXHANDLE handle )
	{
		D3DXPARAMETER_DESC desc;
		const char* value = NULL;
        mDxEffect->GetParameterDesc( handle, &desc );
        mDxEffect->GetString( handle, &value );
		if ( value == NULL ) return NULL;	// TODO:���̂Ƃ��땶����̂݋���

		tinyxml2::XMLElement* element = mXMLDocument.NewElement( "Annotation" );
		element->SetAttribute( "Name", desc.Name );
		element->SetAttribute( "Value", value );

		return element;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	XML::Element* Converter::_createTechniqueElement( D3DXHANDLE handle )
	{
		D3DXTECHNIQUE_DESC desc;
        mDxEffect->GetTechniqueDesc( handle, &desc );

		mCurrentElementPath += desc.Name;
		
		tinyxml2::XMLElement* element = mXMLDocument.NewElement("Technique");
		element->SetAttribute( "Name", desc.Name );

		// �A�m�e�[�V����
        for ( lnU32 i = 0; i < desc.Annotations; ++i )
        {
			D3DXHANDLE anno = mDxEffect->GetAnnotation( handle, i );
			XML::Element* child = _createAnnotationElement( anno );
			if ( child ) {
				element->InsertEndChild( child );
			}
        }

		// �A�m�e�[�V����
		for ( lnU32 i = 0; i < desc.Passes; ++i )
        {
			D3DXHANDLE pass = mDxEffect->GetPass( handle, i );
			XML::Element* child = _createPassElement( pass );
			if ( child ) {
				element->InsertEndChild( child );
			}
		}

		return element;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	XML::Element* Converter::_createPassElement( D3DXHANDLE handle )
	{
		D3DXPASS_DESC desc;
        mDxEffect->GetPassDesc( handle, &desc );

		tinyxml2::XMLElement* element = mXMLDocument.NewElement( "Pass" );
		element->SetAttribute( "Name", desc.Name );

		// �A�m�e�[�V����
        for ( lnU32 i = 0; i < desc.Annotations; ++i )
        {
			D3DXHANDLE anno = mDxEffect->GetAnnotation( handle, i );
			XML::Element* child = _createAnnotationElement( anno );
			if ( child ) {
				element->InsertEndChild( child );
			}
        }

		// �����_�[�X�e�[�g
		struct 
		{
			std::string mKey;

			bool operator()( const HSLSTechniqueAnalyzer::PassInfo& lhs )
			{
				return lhs.Name == mKey;
			}
		} compare;
		compare.mKey = desc.Name;

		HSLSTechniqueAnalyzer::PassInfoArray::iterator itr = 
			std::find_if( mAnalyzer.mPassInfoArray.begin(), mAnalyzer.mPassInfoArray.end(), compare );
		
		_createPassContentsElement( element, *itr, desc.Name );

		return element;

	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	void Converter::_createPassContentsElement( 
		XML::Element* passElement, 
		HSLSTechniqueAnalyzer::PassInfo& passInfo, 
		const char* parentPassName )
	{
		// ���s�����ׂč폜
		//Base::StringUtil::deleteSpace( &passInfo.Contents );
		Base::StringUtil::deleteNewLine( &passInfo.Contents );

		// ; �ŕ���
		std::vector<std::string> expressions;
		Base::StringUtil::split( &expressions, passInfo.Contents.c_str(), ";" );

		ln_foreach( std::string& exp, expressions )
		{
			// = �ŕ���
			std::vector<std::string> pair;
			Base::StringUtil::split( &pair, exp.c_str(), "=" );

			// �܂��͍��ӂ̋󔒂���菜��
			// (�V�F�[�_�֐��͂��̌��͂����邽��)
			Base::StringUtil::deleteSpace( &pair[0] );

			if ( !pair[0].empty() )
			{
				// �V�F�[�_�֐��̏ꍇ
				if ( stricmp( pair[0].c_str(), "VertexShader" ) == 0 ||
					 stricmp( pair[0].c_str(), "PixelShader" ) == 0 )
				{
					Base::Parser parser;
					HSLSCompileExpressionAnalyzer analyzer;
					parser.analyze( pair[1].c_str(), &analyzer );

					// �o�̓t�@�C����
					std::string outputFile = mCurrentElementPath;
					outputFile += ".";
					outputFile += parentPassName;
					outputFile += ".";
					outputFile += pair[0].c_str();

					tinyxml2::XMLElement* element = mXMLDocument.NewElement( pair[0].c_str() );
					//element->SetAttribute( "FunctionName", analyzer.mFuncName.c_str() );
					//element->SetAttribute( "ArgmentList", analyzer.mArgList.c_str() );
					element->SetAttribute( "Shader", outputFile.c_str() );
					passElement->InsertEndChild( element );

					EShLanguage lang = EShLangVertex;
					if ( stricmp( pair[0].c_str(), "PixelShader" ) == 0 ) {
						lang = EShLangFragment;
					}

					_convertHLSL2GLSL(
						mInput,
						outputFile,
						analyzer.mFuncName.c_str(),
						analyzer.mArgList.c_str(),
						lang );
					
				}
				// �����_�[�X�e�[�g�̏ꍇ
				else
				{
					// �E�ӂ̋󔒂���菜��
					Base::StringUtil::deleteSpace( &pair[1] );

					// ���ׂđ啶����
					Base::StringUtil::toUpper( &pair[0][0] );
					Base::StringUtil::toUpper( &pair[1][0] );

					tinyxml2::XMLElement* element = mXMLDocument.NewElement( "RenderState" );
					element->SetAttribute( "Name", pair[0].c_str() );
					element->SetAttribute( "Value", pair[1].c_str() );
					passElement->InsertEndChild( element );
				}
			}
		}
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	bool Converter::_convertHLSL2GLSL( 
		const std::string& input, 
		const std::string& outputFile,
		const std::string& entryPoint,
		const std::string& argmentList,
		EShLanguage lang )
	{
		//printf("--------\n--------\n%s\n--------\n--------\n", input.c_str());


		if ( Hlsl2Glsl_Initialize() == 0 ) {
			printf( "failed Hlsl2Glsl_Initialize.\n" );
			return false;
		}

		//-----------------------------------------------------
		// �R�[�h�ϊ�
		ShHandle shParser = Hlsl2Glsl_ConstructCompiler( EShLangVertex );
		//shParser->

		static EAttribSemantic kAttribSemantic[50] = {
			EAttrSemPosition,
			EAttrSemPosition1,
			EAttrSemPosition2,
			EAttrSemPosition3,
			EAttrSemVPos,
			EAttrSemVFace,
			EAttrSemNormal,
			EAttrSemNormal1,
			EAttrSemNormal2,
			EAttrSemNormal3,
			EAttrSemColor0,
			EAttrSemColor1,
			EAttrSemColor2,
			EAttrSemColor3,
			EAttrSemTex0,
			EAttrSemTex1,
			EAttrSemTex2,
			EAttrSemTex3,
			EAttrSemTex4,
			EAttrSemTex5,
			EAttrSemTex6,
			EAttrSemTex7,
			EAttrSemTex8,
			EAttrSemTex9,
			EAttrSemTangent,
			EAttrSemTangent1,
			EAttrSemTangent2,
			EAttrSemTangent3,
			EAttrSemBinormal,
			EAttrSemBinormal1,
			EAttrSemBinormal2,
			EAttrSemBinormal3,
			EAttrSemBlendWeight,
			EAttrSemBlendWeight1,
			EAttrSemBlendWeight2,
			EAttrSemBlendWeight3,
			EAttrSemBlendIndices,
			EAttrSemBlendIndices1,
			EAttrSemBlendIndices2,
			EAttrSemBlendIndices3,
			EAttrSemPSize,
			EAttrSemPSize1,
			EAttrSemPSize2,
			EAttrSemPSize3,
			EAttrSemDepth,
			EAttrSemUnknown,
			EAttrSemVertexID,
			EAttrSemInstanceID,
			EAttrSemPrimitiveID,
			EAttrSemCoverage,
		};
		static const char* kAttribString[50] = {
			"lnPosition", //EAttrSemPosition,
			"lnPosition1", //EAttrSemPosition1,
			"lnPosition2", //EAttrSemPosition2,
			"lnPosition3", //EAttrSemPosition3,
			"lnVPos",	//EAttrSemVPos,
			"lnVFace", //EAttrSemVFace,
			"lnNormal",	//EAttrSemNormal,
			"lnNormal1",	//EAttrSemNormal1,
			"lnNormal2",	//EAttrSemNormal2,
			"lnNormal3",	//EAttrSemNormal3,
			"lnColor0",	//EAttrSemColor0,
			"lnColor1",	//EAttrSemColor1,
			"lnColor2",	//EAttrSemColor2,
			"lnColor3",	//EAttrSemColor3,
			"lnTexCoord0",	//EAttrSemTex0,
			"lnTexCoord1",	//EAttrSemTex1,
			"lnTexCoord2",	//EAttrSemTex2,
			"lnTexCoord3",	//EAttrSemTex3,
			"lnTexCoord4",	//EAttrSemTex4,
			"lnTexCoord5",	//EAttrSemTex5,
			"lnTexCoord6",	//EAttrSemTex6,
			"lnTexCoord7",	//EAttrSemTex7,
			"lnTexCoord8",	//EAttrSemTex8,
			"lnTexCoord9",	//EAttrSemTex9,
			"lnTangent",	//EAttrSemTangent,
			"lnTangent1",	//EAttrSemTangent1,
			"lnTangent2",	//EAttrSemTangent2,
			"lnTangent3",	//EAttrSemTangent3,
			"lnBinormal",	//EAttrSemBinormal,
			"lnBinormal1",	//EAttrSemBinormal1,
			"lnBinormal2",	//EAttrSemBinormal2,
			"lnBinormal3",	//EAttrSemBinormal3,
			"lnBlendWeight",	//EAttrSemBlendWeight,
			"lnBlendWeight1",	//EAttrSemBlendWeight1,
			"lnBlendWeight2",	//EAttrSemBlendWeight2,
			"lnBlendWeight3",	//EAttrSemBlendWeight3,
			"lnBlendIndices",	//EAttrSemBlendIndices,
			"lnBlendIndices1",	//EAttrSemBlendIndices1,
			"lnBlendIndices2",	//EAttrSemBlendIndices2,
			"lnBlendIndices3",	//EAttrSemBlendIndices3,
			"lnPSize",	//EAttrSemPSize,
			"lnPSize1",	//EAttrSemPSize1,
			"lnPSize2",	//EAttrSemPSize2,
			"lnPSize3",	//EAttrSemPSize3,
			"lnDepth",	//EAttrSemDepth,
			"lnUnknown",	//EAttrSemUnknown,
			"lnVertexID",	//EAttrSemVertexID,
			"lnInstanceID",	//EAttrSemInstanceID,
			"lnPrimitiveID",	//EAttrSemPrimitiveID,
			"lnCoverage",	//EAttrSemCoverage,
		};

		Hlsl2Glsl_SetUserAttributeNames( shParser, kAttribSemantic, kAttribString, 50);
		
		//if (lang == EShLangVertex)
			Hlsl2Glsl_UseUserVaryings(shParser, true);

		unsigned options = 0;
		if (false)
			options |= ETranslateOpIntermediate;
		ETargetVersion version = ETargetGLSL_120;//ETargetGLSL_ES_300;//
		int parseOk = Hlsl2Glsl_Parse ( shParser, input.c_str(), version, options );

		if (parseOk)
		{
			int translateOk = Hlsl2Glsl_Translate (shParser, entryPoint.c_str(), version, options);
		
			if (translateOk) {
				printf ("  translation was expected to fail\n");
			}
		}

		printf( "%s\n", Hlsl2Glsl_GetInfoLog( shParser ) );
		std::string output = Hlsl2Glsl_GetShader( shParser );
		Hlsl2Glsl_DestructCompiler( shParser );

		Hlsl2Glsl_Shutdown();

		//-----------------------------------------------------
		// �����̒u��
		if ( !argmentList.empty() )
		{
			// main() ���� �G���g���[�|�C���g�֐��̌Ăяo����T��
			size_t pos = output.find( "void main()" );
			if ( pos == std::string::npos ) {
				printf( "not found void main()\n" );
				return false;
			}
			pos = output.find( entryPoint.c_str(), pos );
			if ( pos == std::string::npos ) {
				printf( "not found entryPoint\n" );
				return false;
			}
			pos = output.find( "(", pos );
			if ( pos == std::string::npos ) {
				printf( "not found entryPoint ( \n" );
				return false;
			}

			// (...) ���
			Base::Parser parser;
			ArgmentListAnalyzer analyzer;
			parser.analyze( &output[pos], &analyzer );

			// �u����������̐�
			int argCount = Base::StringUtil::countChar( argmentList, 0, ',' );
			argCount += 1;

			// ��납�琔���Ēu��
			const char* begin = analyzer.mArgBeginArray[analyzer.mArgBeginArray.size() - argCount];
			int beginPos = begin - &output[0];
			int len = analyzer.mArgListEnd - begin;
			output.replace( beginPos, len, argmentList );
		}


		//printf(output.c_str());

		OutputShaderInfo info;
		info.ElementPath = outputFile;
		info.ShaderOutput = output;
		mOutputShaderInfoArray.push_back( info );
		return true;
	}


