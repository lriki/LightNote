
#pragma once


#define LNOTE_ENABLE_CRT_DEBUG
#define LNOTE_INCLUDE_ENV_DEPEND_HEADER
#define LNOTE_FOR_200
#include <tinyxml2/tinyxml2.h>
#include "hlsl2glslfork/include/hlsl2glsl.h"
#include "hlsl2glslfork/hlslang/GLSLCodeGen/hlslLinker.h"
#include <lnote.hpp>
#include <Core/Graphics/Device/OpenGL/GLShader.h>
using namespace LNote;
using namespace LNote::Core;

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#ifdef LNOTE_DEBUG
	#pragma comment( lib, "LNote.Dependencies.Debug.lib" )
	#pragma comment( lib, "LNote.Static.Debug.lib" )
#else
	#pragma comment( lib, "LNote.Dependencies.Release.lib" )
	#pragma comment( lib, "LNote.Static.Release.lib" )
#endif



