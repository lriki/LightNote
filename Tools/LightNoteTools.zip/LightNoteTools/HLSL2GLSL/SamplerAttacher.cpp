
#include "stdafx.h"
#include "SamplerAttacher.h"

//=============================================================================
// �� SamplerAttacher
//=============================================================================

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	SamplerAttacher::~SamplerAttacher()
	{
		ln_foreach( TextureVar& var, mTextureVarArray )
		{
			SAFE_RELEASE( var.Texture );
		}
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	void SamplerAttacher::analyze( IDirect3DDevice9* device, ID3DXEffect* effect )
	{
		mDxDevice = device;
		mDxEffect = effect;

		// �܂��̓e�N�X�`���^�ϐ��Ƀ_�~�[�e�N�X�`��������Đݒ�
        for ( UINT i = 0; ; ++i )
        {
            D3DXHANDLE handle = mDxEffect->GetParameter( NULL, i );
            if ( !handle ) break;

			D3DXPARAMETER_DESC desc;
			mDxEffect->GetParameterDesc( handle, &desc );

			switch ( desc.Type )
			{
				case D3DXPT_TEXTURE:
				case D3DXPT_TEXTURE1D:
				case D3DXPT_TEXTURE2D:
				case D3DXPT_TEXTURE3D:
				case D3DXPT_TEXTURECUBE:
				{
					TextureVar texVer;
					texVer.Name = desc.Name;
					IDirect3DTexture9* dxtex;
					HRESULT hr = mDxDevice->CreateTexture( 32, 32, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &dxtex, NULL );
					texVer.Texture = dxtex;
					if ( FAILED( hr ) ) {
						printf( "failed create dummy texture." );
					}
					mTextureVarArray.push_back( texVer );
					mDxEffect->SetTexture( handle, texVer.Texture );
					break;
				}
				default:
					break;
			}
		}

		// �T���v���^�ϐ����Ƃɉ��
        for ( UINT i = 0; ; ++i )
        {
            D3DXHANDLE handle = mDxEffect->GetParameter( NULL, i );
            if ( !handle ) break;

			D3DXPARAMETER_DESC desc;
			mDxEffect->GetParameterDesc( handle, &desc );

			switch ( desc.Type )
			{
				case D3DXPT_SAMPLER:
				case D3DXPT_SAMPLER1D:
				case D3DXPT_SAMPLER2D:
				case D3DXPT_SAMPLER3D:
				case D3DXPT_SAMPLERCUBE:
					analyzeSampler( handle, desc.Name );
					break;
				default:
					break;
			}
		}
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	void SamplerAttacher::analyzeSampler( D3DXHANDLE handle, const char* name )
	{
		printf("�� %s �̌��� ----------------\n", name);
		// TODO �d���̔r��

		for ( UINT iTech = 0; ; ++iTech )
		{
			D3DXHANDLE tech = mDxEffect->GetTechnique( iTech );
			if ( tech ) 
			{
				mDxEffect->SetTechnique( tech );
				UINT passes = 0;
				mDxEffect->Begin( &passes, 0 );
				for ( UINT iPass = 0; iPass < passes; ++iPass )
				{
					mDxEffect->BeginPass( iPass );

					//printf("pass %d ----\n", iPass);

					IDirect3DPixelShader9* ps = NULL;
					mDxDevice->GetPixelShader( &ps );
					if ( ps )
					{
						UINT size;
						ps->GetFunction( NULL, &size );

						lnByte* funcBuf = new lnByte[size];
						ps->GetFunction( funcBuf, &size );

						ID3DXConstantTable* ct;
						D3DXGetShaderConstantTable( (const DWORD*)funcBuf, &ct );

						D3DXHANDLE sampler = ct->GetConstantByName( NULL, name );
						if ( sampler )
						{
							UINT index = ct->GetSamplerIndex( sampler );

							// �T���v���� index �ɃZ�b�g����Ă���e�N�X�`��
							IDirect3DBaseTexture9* basetex;
							mDxDevice->GetTexture( index, &basetex );
							
							if ( basetex )
							{
								IDirect3DBaseTexture9* tex = basetex;//dynamic_cast<IDirect3DTexture9*>( basetex );
								if ( tex )
								{
									TextureVar* var = findTextureVar( tex );
									if ( var )
									{
										SamplerPair pair;
										pair.SamplerVarName = name;
										pair.TextureVarName = var->Name;
										addSamplerPair( pair );
										//printf("�� %s <- %s\n", pair.SamplerVarName.c_str(), pair.TextureVarName.c_str() );
									}
								}
							}
						}


						delete[] funcBuf;
					}


					mDxEffect->EndPass();
				}
				mDxEffect->End();
			}
			else
			{
				break;
			}
		}
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	const char* SamplerAttacher::getTextureNameBySampler( const char* name )
	{
		ln_foreach( SamplerPair& var, mSamplerPairArray )
		{
			if ( var.SamplerVarName == name ) {
				return var.TextureVarName.c_str();
			}
		}
		return NULL;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	SamplerAttacher::TextureVar* SamplerAttacher::findTextureVar( IDirect3DBaseTexture9* texture )
	{
		ln_foreach( TextureVar& var, mTextureVarArray )
		{
			if ( var.Texture == texture ) {
				return &var;
			}
		}
		return NULL;
	}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	void SamplerAttacher::addSamplerPair( const SamplerPair& var )
	{
		SamplerPairArray::iterator itr = std::find( mSamplerPairArray.begin(), mSamplerPairArray.end(), var );
		if ( itr == mSamplerPairArray.end() )
		{
			printf("%s < %s\n", var.SamplerVarName.c_str(), var.TextureVarName.c_str() );
			mSamplerPairArray.push_back( var );
		}
	}


