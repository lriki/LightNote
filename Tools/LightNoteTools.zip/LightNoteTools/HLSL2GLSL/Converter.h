
#pragma once

#include "DXDevice.h"
#include "AnnotationAnalyzer.h"
#include "SamplerAttacher.h"


//=============================================================================
// HSLSTechniqueAnalyzer
//=============================================================================
class HSLSTechniqueAnalyzer
	: public Base::TokenAnalyzer
{
public:

	enum OperatorType 
	{
		OT_LeftBrace = 1,
		OT_RightBrace,
		OT_LeftAngle,
		OT_RightAngle,
		OT_SingleQuotes,
		OT_DoubleQuotes,
	};

	enum KeywordType 
	{
		KT_Technique = 1,
		KT_Pass,
	};

	enum TechniqueSearchSeq
	{
		TechniqueSearchSeq_FindTechnique = 0,
		TechniqueSearchSeq_FindName,
		TechniqueSearchSeq_FindLeftBrace,
		TechniqueSearchSeq_InTechnique,
	};

	enum PassSearchSeq
	{
		PassSearchSeq_FindPass = 0,
		PassSearchSeq_FindName,
		PassSearchSeq_FindLeftBrace,
		PassSearchSeq_InPass,
	};

	enum AnnotationSearchSeq
	{
		PassSearchSeq_FindLeftAngle = 0,
		PassSearchSeq_FindRightAngle,
	};

	struct TechniqueInfo
	{
		std::string		Name;
		const char*		Begin;	// "technique XXX { ... }" �� 't' ���w���Ă���
		const char*		End;	// "technique XXX { ... }" �� '}' ���w���Ă���
	};

	struct PassInfo
	{
		std::string		Name;
		std::string		Contents;
	};

	struct AnnotationInfo
	{
		const char*		Begin;	// '<' ���w���Ă���
		const char*		End;	// ">" ���w���Ă���
	};

	typedef std::vector<TechniqueInfo>	TechniqueInfoArray;
	typedef std::vector<PassInfo>		PassInfoArray;
	typedef std::vector<AnnotationInfo>	AnnotationInfoArray;

public:

	StringLiteralSeq	mStringLiteralSeq;
	TechniqueSearchSeq	mTechniqueSearchSeq;
	int					mCurrentLeftBraceLevel;
	int					mTechniqueLeftBraceLevel;
	PassSearchSeq		mPassSearchSeq;
	int					mPassLeftBraceLevel;

	TechniqueInfo		mCurrentTechniqueInfo;
	TechniqueInfoArray	mTechniqueInfoArray;

	PassInfo			mCurrentPassInfo;
	PassInfoArray		mPassInfoArray;
	const char*			mPassBegin;

	AnnotationSearchSeq	mAnnotationSearchSeq;
	int					mAngleLevel;
	const char*			mAnnotationBegin;		// '<' ���w���Ă���
	AnnotationInfoArray	mAnnotationInfoArray;

public:

	HSLSTechniqueAnalyzer()
	{
		mTechniqueSearchSeq = TechniqueSearchSeq_FindTechnique;
		mCurrentLeftBraceLevel = 0;
		mTechniqueLeftBraceLevel = 0;
		mPassSearchSeq = PassSearchSeq_FindPass;
		mPassLeftBraceLevel = 0;
		mPassBegin = NULL;
		mAnnotationSearchSeq = PassSearchSeq_FindLeftAngle;
		mAngleLevel = 0;
		mAnnotationBegin = NULL;
	}

	virtual const Base::OperatorCode* getOperatorList()
	{
		static const Base::OperatorCode codes[] = 
		{
			{ _T("{"),  1, OT_LeftBrace },
			{ _T("}"),	1, OT_RightBrace },
			{ _T("<"),  1, OT_LeftAngle },
			{ _T(">"),	1, OT_RightAngle },
			{ _T("'"),  1, OT_SingleQuotes },
			{ _T("\""),	1, OT_DoubleQuotes },
			{ NULL,     0, 0 }
		};
		return codes;
	}

	virtual const Base::KeywordCode* getKeywordList()
	{
		static const Base::KeywordCode codes[] = 
		{
			{ _T("pass"),		4, KT_Pass },
			{ _T("technique"),	9, KT_Technique },
			{ NULL,				0, 0 }
		};
		return codes;
	}


	virtual void analyzeToken( const Base::TokenCode& token )
	{
		// �����񃊃e����
		mStringLiteralSeq.analyzeToken( token );
		if ( mStringLiteralSeq.isInStringLiteral() ) {
			return;
		}

		//-----------------------------------------------------
		// { } �̃J�E���g
		if ( token.Type == Base::TOKEN_TYPE_OPERATOR ) {
			if ( token.UserType == OT_LeftBrace ) {
				++mCurrentLeftBraceLevel;
			}
			else if ( token.UserType == OT_RightBrace ) {
				--mCurrentLeftBraceLevel;
			}
		}

		//-----------------------------------------------------
		// �O���[�o�� ( {} �̃l�X�g�� 0) �ɂ��� < > �̃J�E���g
		if ( mCurrentLeftBraceLevel == 0 ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR ) {
				if ( token.UserType == OT_LeftAngle ) {
					++mAngleLevel;
				}
				else if ( token.UserType == OT_RightAngle ) {
					--mAngleLevel;
				}
			}
		}

		//-----------------------------------------------------
		// technique
		// "technique" ��T���Ă���
		if ( mTechniqueSearchSeq == TechniqueSearchSeq_FindTechnique ) {
			if ( token.Type == Base::TokenType_Keyword &&
				 token.UserType == KT_Technique) {
				mCurrentTechniqueInfo.Begin = token.Begin;	
				// ���O��T���ɂ���
				mTechniqueSearchSeq = TechniqueSearchSeq_FindName;
				return;
			}
		}
		// �e�N�j�b�N����T���Ă���
		else if ( mTechniqueSearchSeq == TechniqueSearchSeq_FindName ) {
			if ( token.Type == Base::TOKEN_TYPE_IDENTIFIER ) {
				mCurrentTechniqueInfo.Name = std::string( token.Begin, token.Length );
				// { ��T���ɂ���
				mTechniqueSearchSeq = TechniqueSearchSeq_FindLeftBrace;
				return;
			}
		}
		// technique �� "{" ��T���Ă���
		else if ( mTechniqueSearchSeq == TechniqueSearchSeq_FindLeftBrace ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
				 token.UserType == OT_LeftBrace) {
				// "pass" ��T���ɂ���
				mTechniqueSearchSeq = TechniqueSearchSeq_InTechnique;
				mTechniqueLeftBraceLevel = mCurrentLeftBraceLevel;
				return;
			}
		}
		// technique �̒�
		else if ( mTechniqueSearchSeq == TechniqueSearchSeq_InTechnique ) {
			if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
				 token.UserType == OT_RightBrace &&
				 mCurrentLeftBraceLevel < mTechniqueLeftBraceLevel ) {
				// technique �I��
				mTechniqueSearchSeq = TechniqueSearchSeq_FindTechnique;
				mTechniqueLeftBraceLevel = 0;
				// �m��
				mCurrentTechniqueInfo.End = token.End;	
				mTechniqueInfoArray.push_back( mCurrentTechniqueInfo );
				// �N���A
				mCurrentTechniqueInfo.Name.clear();
				return;
			}
		}

		//-----------------------------------------------------
		// pass
		// technique �̒�
		if ( mTechniqueSearchSeq == TechniqueSearchSeq_InTechnique ) {
			// "pass" ��T���Ă���
			if ( mPassSearchSeq == PassSearchSeq_FindPass ) {
				if ( token.Type == Base::TokenType_Keyword &&
					 token.UserType == KT_Pass) {
					// ���O��T���ɂ���
					mPassSearchSeq = PassSearchSeq_FindName;
					return;
				}
			}
			// �p�X����T���Ă���
			else if ( mPassSearchSeq == PassSearchSeq_FindName ) {
				if ( token.Type == Base::TOKEN_TYPE_IDENTIFIER ) {
					mCurrentPassInfo.Name = std::string( token.Begin, token.Length );
					// { ��T���ɂ���
					mPassSearchSeq = PassSearchSeq_FindLeftBrace;
					return;
				}
			}
			// pass �� "{" ��T���Ă���
			else if ( mPassSearchSeq == PassSearchSeq_FindLeftBrace ) {
				if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
					 token.UserType == OT_LeftBrace) {
					// "pass" ��T���ɂ���
					mPassSearchSeq = PassSearchSeq_InPass;
					mPassLeftBraceLevel = mCurrentLeftBraceLevel;
					mPassBegin = token.Begin + 1;
					return;
				}
			}
			// pass �̒�
			else if ( mPassSearchSeq == PassSearchSeq_InPass ) {
				if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
					 token.UserType == OT_RightBrace &&
					 mCurrentLeftBraceLevel < mPassLeftBraceLevel ) {
					// technique �I��
					mPassSearchSeq = PassSearchSeq_FindPass;
					mPassLeftBraceLevel = 0;
					// �m��
					mCurrentPassInfo.Contents = std::string( mPassBegin, token.Begin - mPassBegin );
					mPassInfoArray.push_back( mCurrentPassInfo );
					// �N���A
					mCurrentPassInfo.Name.clear();
					mCurrentPassInfo.Contents.clear();
					return;
				}
			}
		}

		//-----------------------------------------------------
		// annotation
		if ( mCurrentLeftBraceLevel == 0 )	// �O���[�o���ϐ��̂�
		{
			if ( mAnnotationSearchSeq == PassSearchSeq_FindLeftAngle )
			{
				if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
					 token.UserType == OT_LeftAngle &&
					 mAngleLevel == 1 )
				{
					mAnnotationBegin = token.Begin;
					mAnnotationSearchSeq = PassSearchSeq_FindRightAngle;
					return;
				}
			}
			else if ( mAnnotationSearchSeq == PassSearchSeq_FindRightAngle )
			{
				if ( token.Type == Base::TOKEN_TYPE_OPERATOR &&
					 token.UserType == OT_RightAngle &&
					 mAngleLevel == 0 )
				{
					// �m��
					AnnotationInfo info;
					info.Begin	= mAnnotationBegin;
					info.End	= token.Begin;
					mAnnotationInfoArray.push_back( info );

					// ���Z�b�g
					mAnnotationBegin = NULL;
					mAnnotationSearchSeq = PassSearchSeq_FindLeftAngle;
					return;
				}
			}
		}
	}
};

//=============================================================================
// Converter
//=============================================================================
class Converter
{
public:

	enum ShaderType
	{
		ShaderType_Vertex = 0,
		ShaderType_Pixel,
	};

	struct OutputShaderInfo
	{
		std::string ElementPath;
		std::string ShaderOutput;
	};

	typedef std::vector<OutputShaderInfo>	OutputShaderInfoArray;

public:

	~Converter();

public:

	bool convert( const char* filePath, DXDevice* device );

public:

	XML::Element* _createVariableElement( D3DXHANDLE handle );
	XML::Element* _createAnnotationElement( D3DXHANDLE handle );
	XML::Element* _createTechniqueElement( D3DXHANDLE handle );
	XML::Element* _createPassElement( D3DXHANDLE handle );
	void _createPassContentsElement( XML::Element* passElement, HSLSTechniqueAnalyzer::PassInfo& passInfo, const char* parentPassName );
	bool _convertHLSL2GLSL( 
		const std::string& input, 
		const std::string& outputFile,
		const std::string& entryPoint,
		const std::string& argmentList,
		EShLanguage lang );

private:
	static const lnChar* TmpFileName;

	std::string				mFilePath;
	DXDevice*				mDxDevice;
	ID3DXEffect*			mDxEffect;
	XML::Document			mXMLDocument;
	HSLSTechniqueAnalyzer	mAnalyzer;
	std::string				mCurrentElementPath;
	std::string				mInput;
	OutputShaderInfoArray	mOutputShaderInfoArray;
	SamplerAttacher			mSamplerAttacher;
};

