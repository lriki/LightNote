


//=============================================================================
// �� OutputFile
//-----------------------------------------------------------------------------
//	
//=============================================================================
class OutputFile
{
public:

	OutputFile()
	{
		mStream = NULL;
	}

	~OutputFile()
	{
		close();
	}

public:

	bool open( const char* filePath )
	{
		mStream = fopen( filePath, "wb" );
		if ( !mStream ) return false;

		// �}�W�b�N�i���o�[
		fwrite( Core::Graphics::LNFXFile::Magic, 1, 4, mStream );

		// �t�@�C���o�[�W����
		lnU8 v = 1;
		fwrite( &v, 1, 1, mStream );

		return true;
	}

	void close()
	{
		if ( mStream ) {
			fclose( mStream );
			mStream = NULL;
		}
	}

	/// �擪��HLSL
	bool addHLSL( const std::string& hlsl )
	{
		lnU32 size = hlsl.length();
		fwrite( &size, 1, 4, mStream );
		fwrite( hlsl.c_str(), 1, size, mStream );

		return true;
	}

	/// 2�Ԗڂ� XML �w�b�_�p
	bool addXMLFile( const char* filePath )
	{
		FILE* fp = fopen( filePath, "rb" );
		if ( !fp ) return false;

		lnU32 size = Core::FileIO::File::getFileSize( fp );
		fseek( fp, 0, SEEK_SET );

		lnByte* buf = new lnByte[size];
		fread( buf, 1, size, fp );

		fwrite( &size, 1, 4, mStream );
		fwrite( buf, 1, size, mStream );

		delete[] buf;
		return true;
	}

	/// �L�[�A�T�C�Y�A�R���e���c
	bool addNamedText( const std::string& name, const std::string& text )
	{
		lnU32 size = name.length();
		fwrite( &size, 1, 4, mStream );
		fwrite( name.c_str(), 1, size, mStream );

		size = text.length();
		fwrite( &size, 1, 4, mStream );
		fwrite( text.c_str(), 1, size, mStream );

		return true;
	}

private:

	FILE*	mStream;
};


