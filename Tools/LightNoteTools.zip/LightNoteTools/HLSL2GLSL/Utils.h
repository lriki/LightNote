
#include <iostream>
#include <string>

class Utils
{
	static void replace_string (std::string& target, const std::string& search, const std::string& replace, size_t startPos)
	{
		if (search.empty())
			return;
	
		std::string::size_type p = startPos;
		while ((p = target.find (search, p)) != std::string::npos)
		{
			target.replace (p, search.size (), replace);
			p += replace.size ();
		}
	}

	static bool ReadStringFromFile (const char* pathName, std::string& output)
	{
		FILE* file = fopen( pathName, "rb" );
		if (file == NULL)
			return false;
	
		fseek(file, 0, SEEK_END);
		long length = ftell(file);
		fseek(file, 0, SEEK_SET);
		if (length < 0)
		{
			fclose( file );
			return false;
		}
	
		output.resize(length);
		size_t readLength = fread(&*output.begin(), 1, length, file);
	
		fclose(file);
	
		if (readLength != length)
		{
			output.clear();
			return false;
		}

		replace_string(output, "/r/n", "/n", 0);
	
		return true;
	}
};

