﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Common.Views
{
    /// <summary>
    /// FolderBrowseTextBox.xaml の相互作用ロジック
    /// </summary>
    public partial class FolderBrowseTextBox : UserControl
    {
        public FolderBrowseTextBox()
        {
            InitializeComponent();
            _textBox1.DataContext = this;
        }

        // ブラウズボタン
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var dialog = new Ookii.Dialogs.Wpf.VistaFolderBrowserDialog();
            if (dialog.ShowDialog() == true)
            {
                FolderPath = dialog.SelectedPath;
            }
        }


        // Enter キーを押したときもバインディングソースを更新する
        private void _textBox1_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                FolderPath = _textBox1.Text;
            }
        }

        public string FolderPath
        {
            get { return (string)GetValue(FolderPathProperty); }
            set { SetValue(FolderPathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FolderPath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FolderPathProperty =
            DependencyProperty.Register("FolderPath", typeof(string), typeof(FolderBrowseTextBox), new PropertyMetadata(OnFolderPathPropertyChanged));
        private static void OnFolderPathPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            // FolderPath.set で RaisePropatyChanged() してもいいけど、まぁ先に作っちゃったので。
            (sender as FolderBrowseTextBox)._textBox1.Text = (e.NewValue as string);
        }



    }
}
