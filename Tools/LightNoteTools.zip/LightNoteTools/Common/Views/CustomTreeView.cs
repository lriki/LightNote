﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Common.Views
{
    /// <summary>
    /// このカスタム コントロールを XAML ファイルで使用するには、手順 1a または 1b の後、手順 2 に従います。
    ///
    /// 手順 1a) 現在のプロジェクトに存在する XAML ファイルでこのカスタム コントロールを使用する場合
    /// この XmlNamespace 属性を使用場所であるマークアップ ファイルのルート要素に
    /// 追加します:
    ///
    ///     xmlns:MyNamespace="clr-namespace:Common.Views"
    ///
    ///
    /// 手順 1b) 異なるプロジェクトに存在する XAML ファイルでこのカスタム コントロールを使用する場合
    /// この XmlNamespace 属性を使用場所であるマークアップ ファイルのルート要素に
    /// 追加します:
    ///
    ///     xmlns:MyNamespace="clr-namespace:Common.Views;assembly=Common.Views"
    ///
    /// また、XAML ファイルのあるプロジェクトからこのプロジェクトへのプロジェクト参照を追加し、
    /// リビルドして、コンパイル エラーを防ぐ必要があります:
    ///
    ///     ソリューション エクスプローラーで対象のプロジェクトを右クリックし、
    ///     [参照の追加] の [プロジェクト] を選択してから、このプロジェクトを参照し、選択します。
    ///
    ///
    /// 手順 2)
    /// コントロールを XAML ファイルで使用します。
    ///
    ///     <MyNamespace:TreeView/>
    ///
    /// </summary>
    public class CustomTreeView : TreeView
    {
        private object _draggedData;        // ドラッグ中アイテムの DataContext
        private Point _initialPosition;
        private Point _mouseOffsetFromItem;
        private int _draggedDataContextIndex = -1;   // ドラッグ中の Item が持つ DataContext の兄弟間のインデックス    

        private  Parts.InsertionAdorner _insertionAdorner;
        //private DragContentAdorner _dragContentAdorner;

        private FrameworkElement _lastDraggedOveredElement;
        private bool _lastShowInBottomChild = false;

        static CustomTreeView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CustomTreeView), new FrameworkPropertyMetadata(typeof(TreeView)));
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CustomTreeView()
        {
            this.AllowDrop = true;

            this.PreviewMouseLeftButtonDown += TreeView_PreviewMouseLeftButtonDown;
            this.PreviewMouseMove += TreeView_PreviewMouseMove;
            this.PreviewMouseUp += TreeView_PreviewMouseUp;

            this.PreviewDragEnter += TreeView_PreviewDragEnter;
            this.PreviewDragLeave += TreeView_PreviewDragLeave;
            this.PreviewDragOver += TreeView_PreviewDragOver;
            this.PreviewDrop += TreeView_PreviewDrop;
            
        }

        /// <summary>
        /// D&D 関係のデータのクリア
        /// </summary>
        private void CleanUpDragData()
        {
            _draggedData = null;
            
            if (_insertionAdorner != null) { _insertionAdorner.Detach(); }
/*
            if (_dragContentAdorner != null) { _dragContentAdorner.Detach(); }
 * */
            _insertionAdorner = null;

            _draggedDataContextIndex = -1;
        }

        
        private void CreateInsertionAdorner(DependencyObject draggedItem, ItemsControl itemsControl)
        {

            var draggedOveredContainer = Utils.GetItemContainer(itemsControl, draggedItem);
            bool showInBottom = false;
            if (draggedOveredContainer == null)
            {
                draggedOveredContainer = Utils.GetLastContainer(itemsControl);
                showInBottom = true;
            }

            _insertionAdorner = new Parts.InsertionAdorner(draggedOveredContainer, showInBottom);
        }
        

        /// <summary>
        /// 挿入カーソルの位置を更新する
        /// </summary>
        /// <param name="draggedOveredElement">カーソルの基準コントロール (ドラッグ中、マウス位置にあるコントロール)</param>
        /// <param name="showInBottomChild"></param>
        private void SetInsertionCursorState(FrameworkElement draggedOveredElement, bool showInBottomChild)
        {
            // InsertionAdorner の破棄
            if (draggedOveredElement == null)
            {
                if (_insertionAdorner != null)
                {
                    _insertionAdorner.Detach();
                    _insertionAdorner = null;
                }
                _lastDraggedOveredElement = null;
                return;
            }

            // カーソル位置コントロールが異なる場合は Adorner を再作成
            // (装飾対象のコントロールはコンストラクタで設定するしかなく、後から変更できないため)
            if (draggedOveredElement != _lastDraggedOveredElement ||
                showInBottomChild != _lastShowInBottomChild)
            {
                if (_insertionAdorner != null)
                {
                    _insertionAdorner.Detach();
                }
                _insertionAdorner = new Parts.InsertionAdorner(draggedOveredElement);
                _lastDraggedOveredElement = draggedOveredElement;
                _lastShowInBottomChild = showInBottomChild;
            }

            if (!showInBottomChild)
            {
                _insertionAdorner.setVerticalAlignment(System.Windows.VerticalAlignment.Top);
                _insertionAdorner.setMargin(new Thickness(0, 0, 0, 0));
            }
            else
            {
                _insertionAdorner.setVerticalAlignment(System.Windows.VerticalAlignment.Bottom);
                _insertionAdorner.setMargin(new Thickness(16, 0, 0, 0));
            }
        }

        /// <summary>
        /// InsertionAdorner の破棄
        /// </summary>
        private void CreanUpInsertionAdorner()
        {
            _insertionAdorner.Detach();
            _insertionAdorner = null;
        }

        /// <summary>
        /// ドラッグ開始十分な量の移動量か確認
        /// </summary>
        /// <param name="delta"></param>
        /// <returns></returns>
        private static bool MovedEnoughForDrag(Vector delta)
        {
            return Math.Abs(delta.X) > SystemParameters.MinimumHorizontalDragDistance
                   && Math.Abs(delta.Y) > SystemParameters.MinimumVerticalDragDistance;
        }

        private void TreeView_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // e.OriginalSource には、実際にイベントを処理したオブジェクトが格納されている。
            // 例えば、アイテムのテンプレートが TextBlock になっている場合は TextBlock、
            // ツリービューの何もないところをクリックした場合は Grid、
            // 展開ボタンをクリックした場合は Shapes.Path となる。
            var draggedItem = e.OriginalSource as FrameworkElement;
            if (draggedItem == null) { return; }

            // draggedItem から、それを持っているコンテナ(TreeViewItem)を持ってくる
            var treeViewItem = Utils.GetItemContainer(this, draggedItem) as TreeViewItem;
            if (treeViewItem == null) { return; }

           // System.Console.WriteLine("parent:{0}", Utils.GetParentTreeViewItem(treeViewItem));
            //System.Console.WriteLine(VisualTreeHelper.GetParent(itemsControl));
            
            // クリックしたコンテナの DataContext を取得する
            _draggedData = treeViewItem.DataContext;//Utils.GetItemData(treeViewItem, draggedItem);
            if (_draggedData == null) { return; }

            // ドラッグ開始判定用のマウス位置
            _initialPosition = this.PointToScreen(e.GetPosition(this));
            _mouseOffsetFromItem = treeViewItem.PointFromScreen(_initialPosition);
            //_mouseOffsetFromItem = Utils.PointToItem(itemsControl, draggedItem, _initialPosition.Value);


            //ItemsControl parentTreeViewItem

            // 親 TreeViewItem 内でのインデックスを覚えておく
            var parentTreeViewItem = Utils.GetParentTreeViewItem(treeViewItem);
            if (parentTreeViewItem != null)
            {
                _draggedDataContextIndex = Utils.GetItemIndex(parentTreeViewItem, _draggedData);
            }
            // 親アイテムがない場合は TreeView
            else
            {
                _draggedDataContextIndex = Utils.GetItemIndex(this, _draggedData);
            }
            
        }

        private void TreeView_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            var itemsControl = sender as ItemsControl;

            if (_draggedData == null || _initialPosition == null || itemsControl == null)
            {
                return;
            }

            var currentPos = this.PointToScreen(e.GetPosition(this));
            if (!MovedEnoughForDrag((_initialPosition - currentPos)))
            {
                return;
            }

            //_dragContentAdorner = new DragContentAdorner(
            //    itemsControl, _draggedData, itemsControl.ItemTemplate, _mouseOffsetFromItem);
            //_dragContentAdorner.SetScreenPosition(currentPos);

            // D&D の開始 (ドロップされるまで処理を返さない)
            DragDrop.DoDragDrop(itemsControl, _draggedData, DragDropEffects.Move);
            
            CleanUpDragData();
        }

        private void TreeView_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            CleanUpDragData();
        }

        private void TreeView_PreviewDragEnter(object sender, DragEventArgs e)
        {
            System.Console.WriteLine("TreeView_PreviewDragEnter");
            var itemsControl = sender as ItemsControl;
            if (itemsControl == null) { return; }

            //CreateInsertionAdorner(e.OriginalSource as DependencyObject, itemsControl);
        }

        private void TreeView_PreviewDragLeave(object sender, DragEventArgs e)
        {
            System.Console.WriteLine("TreeView_PreviewDragLeave");
            if (_insertionAdorner != null)
            {
                CreanUpInsertionAdorner();
            }
        }

        private void TreeView_PreviewDragOver(object sender, DragEventArgs e)
        {
            // Adorner とか使わない普通の場合は、ここでドラッグしてきたアイテムの種類から
            // e.Effects = DragDropEffects.Copy; 等設定を行う。
            // D&D中(左ボタンを押しっぱなしにしている間)そこそこの間隔(0.2sくらい)で定期的に呼ばれる


            var overElement = Utils.GetItemContainer(this, e.OriginalSource as DependencyObject);
            if (overElement != null)
            {
                var localPos = e.GetPosition(overElement);
                if (localPos.Y < overElement.ActualHeight / 2)
                {
                    SetInsertionCursorState(overElement, false);
                }
                else
                {
                    SetInsertionCursorState(overElement, true);
                }
            }

            /*
            var currentPos = this.PointToScreen(e.GetPosition(this));
            _dragContentAdorner.SetScreenPosition(currentPos);
             * */
        }

        private void TreeView_PreviewDrop(object sender, DragEventArgs e)
        {
            var itemsControl = sender as ItemsControl;
            if (itemsControl == null) { return; }

            // e.OriginalSource は ドロップ先のコントロール。
            // TreeViewItem 内の TextBlock 等が来る。
            // dropTargetData には、ドロップ先の TreeViewItem の DataContext が入ることになる。
            var dropTargetData = Utils.GetItemData(itemsControl, e.OriginalSource as DependencyObject);
            //DropItemAt(itemsControl.GetItemIndex(dropTargetData), itemsControl);
        }
    }
}
