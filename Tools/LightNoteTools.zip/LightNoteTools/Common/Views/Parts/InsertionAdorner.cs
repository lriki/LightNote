﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Common.Views.Parts
{
    class InsertionAdorner : ControlHostAdornerBase
    {
        private readonly HorizontalInsertionCursor _insertionCursor;

        public InsertionAdorner(FrameworkElement adornedElement)
            : base(adornedElement)
        {
            _insertionCursor = new HorizontalInsertionCursor();

            Host.Children.Add(_insertionCursor);

            _insertionCursor.SetValue(HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            _insertionCursor.SetValue(VerticalAlignmentProperty, VerticalAlignment.Top);

            //_insertionCursor.SetValue(VerticalAlignmentProperty,
            //    showInBottomSide ? VerticalAlignment.Bottom : VerticalAlignment.Top);
            //_insertionCursor.SetValue(HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
        }

        public void setVerticalAlignment(VerticalAlignment align)
        {
            //Host.SetValue(VerticalAlignmentProperty, align);
            //_insertionCursor.SetValue(VerticalAlignmentProperty, align);
            _insertionCursor.VerticalAlignment = align;

            

        }

        public void setMargin(Thickness margin)
        {
            _insertionCursor.SetValue(MarginProperty, margin);
        }

        // 削除予定
        public InsertionAdorner(FrameworkElement adornedElement, bool showInBottomSide = false)
            : base(adornedElement)
        {
            _insertionCursor = new HorizontalInsertionCursor();

            Host.Children.Add(_insertionCursor);

            _insertionCursor.SetValue(VerticalAlignmentProperty,
                showInBottomSide ? VerticalAlignment.Bottom : VerticalAlignment.Top);
            _insertionCursor.SetValue(HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
        }


    }
}
