﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Common.Views
{
    class Utils
    {
        /// <summary>
        /// GetItemContainer() で得られたコンテナにバインドしているオブジェクト (DataContext) を取得する
        /// </summary>
        public static object GetItemData(ItemsControl itemsControl, DependencyObject item)
        {
            var data = GetItemContainer(itemsControl, item);
            return data == null ? null : data.DataContext;
        }

        /// <summary>
        /// ItemsControl のコンテナ内に構築された VisualTree 内のいずれかの要素からコンテナ（ListBoxItemやListViewItem）を特定する。
        /// 例えば TreeView のアイテムをクリックしたときに得られる TextBlock 等から、それを格納している TreeViewItem を取得できる。
        /// </summary>
        public static FrameworkElement GetItemContainer(ItemsControl itemsControl, DependencyObject item)
        {
            if (itemsControl == null || item == null)
            {
                return null;
            }
            if (itemsControl is TreeView)
            {
                return GetCetontainerFromElement((TreeView)itemsControl, item) as FrameworkElement;
            }
            else
            {
                return itemsControl.ContainerFromElement(item) as FrameworkElement;
            }
        }

        /// <summary>
        /// スクリーン上の座標を、GetItemContainer() で得られたコンテナのローカル座標系に変換する
        /// </summary>
        public static Point PointToItem(ItemsControl itemsControl, DependencyObject item, Point screenPos)
        {
            var itemContainer = GetItemContainer(itemsControl, item);
            return itemContainer == null ? new Point() : itemContainer.PointFromScreen(screenPos);
        }

        /// <summary>
        /// item が itemsControl.ItemsSource のどこに含まれているかを返す
        /// </summary>
        public static int GetItemIndex(ItemsControl itemsControl, object item)
        {
            var itemsSourceList = itemsControl.ItemsSource as IList;
            if (itemsSourceList == null)
            {
                return -1;
            }
            return itemsSourceList.IndexOf(item);
        }

        public static FrameworkElement GetLastContainer(ItemsControl itemsControl)
        {
            return itemsControl.ItemContainerGenerator.ContainerFromIndex
                       (itemsControl.Items.Count - 1) as FrameworkElement;
        }

        public static TreeViewItem GetParentTreeViewItem(TreeViewItem item)
        {
            var parent = VisualTreeHelper.GetParent(item);
            while (!(parent is TreeViewItem || parent is TreeView))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }
            return parent as TreeViewItem;
        }

        /// <summary>
        /// TreeView 用の ContainerFromElement。
        /// こうしないと、どんなに深いところにある子 TreeViewItem 内の要素から取得しても、
        /// 常にルートノードが返ってしまう。
        /// </summary>
        /// <param name="treeView"></param>
        /// <param name="buttomControl"></param>
        /// <returns></returns>
        private static TreeViewItem GetCetontainerFromElement(TreeView treeView, DependencyObject buttomControl)
        {
            return GetGCetontainerFromElementList(treeView, buttomControl).LastOrDefault() as TreeViewItem;
        }

        private static IEnumerable<ItemsControl> GetGCetontainerFromElementList(ItemsControl topItemsControl, DependencyObject buttomControl)
        {
            ItemsControl tmp = topItemsControl;
            while (tmp != null)
            {
                tmp = ItemsControl.ContainerFromElement(tmp, buttomControl) as ItemsControl;
                if (tmp != null)
                {
                    yield return tmp;
                }
            }
        }
    }
}
