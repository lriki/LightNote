﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Common.Views
{
    /// <summary>
    /// Triangle.xaml の相互作用ロジック
    /// </summary>
    public partial class Triangle : UserControl
    {
        public Triangle()
        {
            InitializeComponent();
            Stroke = Brushes.Green;
        }

        //public IEnumerator Points
        //{
        //    get
        //    {
        //        yield return Point1;
        //        yield return Point2;
        //        yield return Point3;
        //    }
        //}

        public Brush Fill
        {
            get { return (Brush)GetValue(FillProperty); }
            set { SetValue(FillProperty, value); }
        }
        public static DependencyProperty FillProperty =
            DependencyProperty.Register("Fill",
            typeof(Brush),
            typeof(Triangle),
            new FrameworkPropertyMetadata(Brushes.Black));

        public Brush Stroke
        {
            get { return (Brush)GetValue(StrokeProperty); }
            set { SetValue(StrokeProperty, value); }
        }
        public static DependencyProperty StrokeProperty =
            DependencyProperty.Register("Stroke",
            typeof(Brush),
            typeof(Triangle),
            new FrameworkPropertyMetadata(Brushes.Black));

        public double StrokeThickness
        {
            get { return (double)GetValue(StrokeThicknessProperty); }
            set { SetValue(StrokeThicknessProperty, value); }
        }
        public static DependencyProperty StrokeThicknessProperty =
            DependencyProperty.Register("StrokeThickness",
            typeof(double),
            typeof(Triangle),
            new FrameworkPropertyMetadata(0.0));



        public PointCollection Points
        {
            get { return (PointCollection)GetValue(PointsProperty); }
            set { SetValue(PointsProperty, value); }
        }

        public static readonly DependencyProperty PointsProperty = DependencyProperty.Register(
            "Points", 
            typeof(PointCollection), 
            typeof(Triangle),
            new FrameworkPropertyMetadata(new PointCollection() { new Point(0, 0), new Point(10, 0), new Point(0, 10) }));



        /*
        public Point Point1
        {
            get { return (Point)GetValue(Point1PropertyProperty); }
            set { SetValue(Point1PropertyProperty, value); }
        }
        public static readonly DependencyProperty Point1PropertyProperty =
            DependencyProperty.Register("Point1Property", typeof(Point), typeof(Triangle), new FrameworkPropertyMetadata(new Point(0, 0)));

        public Point Point2
        {
            get { return (Point)GetValue(Point2PropertyProperty); }
            set { SetValue(Point2PropertyProperty, value); }
        }
        public static readonly DependencyProperty Point2PropertyProperty =
            DependencyProperty.Register("Point2Property", typeof(Point), typeof(Triangle), new FrameworkPropertyMetadata(new Point(10, 0)));


        public Point Point3
        {
            get { return (Point)GetValue(Point3PropertyProperty); }
            set { SetValue(Point3PropertyProperty, value); }
        }
        public static readonly DependencyProperty Point3PropertyProperty =
            DependencyProperty.Register("Point3Property", typeof(Point), typeof(Triangle), new FrameworkPropertyMetadata(new Point(0, 10)));
        */
    }
}
