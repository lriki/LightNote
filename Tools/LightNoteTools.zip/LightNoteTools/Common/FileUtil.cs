﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class FileUtil
    {
        // rootPath 以下のファイルの走査(返すファイル名にはrootPathのフォルダ名を含む)
        public static string[] MakeTree(string rootPath)
        {
            //this.listView1.Items.Clear();

            //string dirName = System.IO.Path.GetFileName(rootPath) + "\\";
            string root_directry_name = "";//
            //root_directry_name += "\\";
            string[] filenames = getFilesMostDeep(rootPath, "*.*", root_directry_name);

            for (int i = 0; i < filenames.Length; ++i)
            {
                filenames[i] = filenames[i];
            }
            return filenames;
        }

        // MakeTree() から呼ばれる
        public static string[] getFilesMostDeep(string root_path_, string pattern_, string parent_path_)
        {
            System.Collections.Specialized.StringCollection hStringCollection = (
                new System.Collections.Specialized.StringCollection()
            );

            // このディレクトリ内のすべてのファイルを検索する
            foreach (string file_path in System.IO.Directory.GetFiles(root_path_, pattern_))
            {
                string ts = parent_path_ + System.IO.Path.GetFileName(file_path);
                hStringCollection.Add(ts);
            }

            // このディレクトリ内のすべてのサブディレクトリを検索する (再帰)
            foreach (string dir_path in System.IO.Directory.GetDirectories(root_path_))
            {
                string ts = parent_path_ + System.IO.Path.GetFileName(dir_path) + "\\";
                string[] file_pathes = getFilesMostDeep(dir_path, pattern_, ts);

                // 条件に合致したファイルがあった場合は、ArrayList に加える
                if (file_pathes != null)
                {
                    hStringCollection.AddRange(file_pathes);
                }
            }

            // StringCollection を 1 次元の String 配列にして返す
            string[] stReturns = new string[hStringCollection.Count];

            hStringCollection.CopyTo(stReturns, 0);



            return stReturns;
        }
    }
}
