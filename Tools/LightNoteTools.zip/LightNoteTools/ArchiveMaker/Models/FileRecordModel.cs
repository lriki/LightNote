﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Livet;

namespace ArchiveMaker.Models
{
    public class FileRecordModel : NotificationObject
    {
        /// <summary>
        /// アーカイブにパックするかどうか
        /// </summary>
        #region Enable変更通知プロパティ
        public bool Enable
        {
            get { return _Enable; }
            set
            { 
                if (_Enable == value)
                    return;
                _Enable = value;
                RaisePropertyChanged(() => Enable);
            }
        }
        private bool _Enable;
        #endregion

        #region AccessName変更通知プロパティ
        private string _AccessName;
        /// <summary>
        /// ライブラリからアクセスするときのパス
        /// </summary>
        public string AccessName
        {
            get { return _AccessName; }
            set
            { 
                if (_AccessName == value)
                    return;
                _AccessName = value;
                RaisePropertyChanged(() => AccessName);
            }
        }
        #endregion

        #region PackingFilePath変更通知プロパティ
        private string _PackingFilePath;
        /// <summary>
        /// 取り込むファイルのパス
        /// </summary>
        public string PackingFilePath
        {
            get { return _PackingFilePath; }
            set
            { 
                if (_PackingFilePath == value)
                    return;
                _PackingFilePath = value;
                RaisePropertyChanged(() => PackingFilePath);
            }
        }
        #endregion

        #region ResultMessage変更通知プロパティ
        private string _ResultMessage;
        /// <summary>
        /// 作成結果メッセージ
        /// </summary>
        public string ResultMessage
        {
            get { return _ResultMessage; }
            set
            { 
                if (_ResultMessage == value)
                    return;
                _ResultMessage = value;
                RaisePropertyChanged(() => ResultMessage);
            }
        }
        #endregion



    }
}
