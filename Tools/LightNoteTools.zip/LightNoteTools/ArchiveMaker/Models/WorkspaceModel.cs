﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Livet;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Threading;

namespace ArchiveMaker.Models
{
    public class WorkspaceModel : NotificationObject
    {
        /// <summary>
        /// 入力ディレクトリ
        /// </summary>
        #region TargetDirectoryPath変更通知プロパティ
        public string TargetDirectoryPath
        {
            get { return _TargetDirectoryPath; }
            set
            { 
                if (_TargetDirectoryPath == value)
                    return;
                _TargetDirectoryPath = value;
                RaisePropertyChanged(() => TargetDirectoryPath);

                OutputArchiveFile = TargetDirectoryPath + ".lna";
            }
        }
        private string _TargetDirectoryPath;
        #endregion

        /// <summary>
        /// 出力アーカイブファイル
        /// </summary>
        #region OutputArchiveFile変更通知プロパティ
        public string OutputArchiveFile
        {
            get { return _OutputArchiveFile; }
            set
            { 
                if (_OutputArchiveFile == value)
                    return;
                _OutputArchiveFile = value;
                RaisePropertyChanged(() => OutputArchiveFile);

                // ファイル一覧を作る
                FileRecordList.Clear();
                string[] filePaths = Common.FileUtil.MakeTree(_TargetDirectoryPath);
                foreach (string path in filePaths)
                {
                    var record = new FileRecordModel()
                    {
                        Enable = true,
                        AccessName = path,
                        PackingFilePath = _TargetDirectoryPath + "\\" + path,
                    };
                    FileRecordList.Add(record);
                }
            }
        }
        private string _OutputArchiveFile;
        #endregion


        #region FileRecordList変更通知プロパティ
        private ObservableCollection<FileRecordModel> _FileRecordList = new ObservableCollection<FileRecordModel>();
        /// <summary>
        /// ファイル一覧
        /// </summary>
        public ObservableCollection<FileRecordModel> FileRecordList
        {
            get { return _FileRecordList; }
            set
            { 
                if (_FileRecordList == value)
                    return;
                _FileRecordList = value;
                RaisePropertyChanged(() => FileRecordList);
            }
        }
        #endregion


        #region Password変更通知プロパティ
        private string _Password;
        /// <summary>
        /// アーカイブのパスワード
        /// </summary>
        public string Password
        {
            get { return _Password; }
            set
            { 
                if (_Password == value)
                    return;
                _Password = value;
                RaisePropertyChanged(() => Password);
            }
        }
        #endregion


        /// <summary>
        /// コンストラクタ
        /// </summary>
        public WorkspaceModel()
        {
        }

        /// <summary>
        /// アーカイブファイル作成実行
        /// </summary>
        public void CreateArchive()
        {
            // 最初に全 Result をリセット
            foreach (var record in _FileRecordList)
            {
                if (record.Enable)
                {
                    record.ResultMessage = "[" + Properties.Resources.Waiting + "]";
                }
                else
                {
                    record.ResultMessage = "";
                }
            }

            // アーカイブファイルを作る
            var maker = new LightNote.Core.ArchiveMaker();
            maker.open(_OutputArchiveFile, _Password);

            foreach (var record in _FileRecordList)
            {
                if (record.Enable)
                {
                    bool r = maker.addFile(record.PackingFilePath, record.AccessName);
                    if (r)
                    {
                        record.ResultMessage = "[" + Properties.Resources.Success + "]";
                    }
                    else
                    {
                        record.ResultMessage = "[" + Properties.Resources.Failed + "]";
                    }
                }

                Application.Current.Dispatcher.Invoke(
                    new Action(() => { }), DispatcherPriority.Background, new object[] { });
            }

            maker.close();
        }
    }
}
