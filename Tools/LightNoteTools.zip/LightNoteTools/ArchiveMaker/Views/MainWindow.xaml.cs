﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;

namespace ArchiveMaker.Views
{
    /* 
     * ViewModelからの変更通知などの各種イベントを受け取る場合は、PropertyChangedWeakEventListenerや
     * CollectionChangedWeakEventListenerを使うと便利です。独自イベントの場合はLivetWeakEventListenerが使用できます。
     * クローズ時などに、LivetCompositeDisposableに格納した各種イベントリスナをDisposeする事でイベントハンドラの開放が容易に行えます。
     *
     * WeakEventListenerなので明示的に開放せずともメモリリークは起こしませんが、できる限り明示的に開放するようにしましょう。
     */

    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //WPF.Themes.ThemeManager.ApplyTheme(Application.Current, "ExpressionDark");
            //WPF.Themes.ThemeManager.ApplyTheme(Application.Current, null);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CultureResources.ChangeCulture(CultureInfo.GetCultureInfo("en-US"));
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CultureResources.ChangeCulture(CultureInfo.GetCultureInfo("ja-JP"));
        }

        private void Close_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.Close();
        }





        class AppLanguageInfo
        {
            public string Name;
            public string Culture;

            public override string ToString() { return Name; }
        };

        private List<MenuItem> _themesMenuItemList = new List<MenuItem>();

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            _themesMenuItemList.Clear();
            foreach (string name in WPF.Themes.ThemeManager.GetThemes())
            {
                var item = new MenuItem();
                item.Header = name;
                item.Click += _menuThemesItem_Click_1;
                _themesMenuItemList.Add(item);
                _menuThemes.Items.Add(item);
            }

            WPF.Themes.ThemeManager.ApplyTheme(Application.Current, "Default");

            var langInfo = new AppLanguageInfo() { Name = "English", Culture = "en-US" };
            var menuItem = new MenuItem() { Header = langInfo };
            menuItem.Click += _menuLanguagesItem_Click_1;
            _menuLanguage.Items.Add(menuItem);

            langInfo = new AppLanguageInfo() { Name = "日本語", Culture = "ja-JP" };
            menuItem = new MenuItem() { Header = langInfo };
            menuItem.Click += _menuLanguagesItem_Click_1;
            _menuLanguage.Items.Add(menuItem);
        }

        private void _menuThemesItem_Click_1(object sender, RoutedEventArgs e)
        {
            // 最初にすべてのチェックを外す
            foreach (MenuItem item in _themesMenuItemList)
            {
                item.IsChecked = false;
            }

            var senderItem = sender as MenuItem;
            if (senderItem != null && senderItem.Header is string)
            {
                senderItem.IsChecked = true;
                WPF.Themes.ThemeManager.ApplyTheme(Application.Current, senderItem.Header as string);
            }
        }

        private void _menuLanguagesItem_Click_1(object sender, RoutedEventArgs e)
        {
            var senderItem = sender as MenuItem;
            if (senderItem != null)
            {
                senderItem.IsChecked = true;
                string lang = (senderItem.Header as AppLanguageInfo).Culture;
                CultureResources.ChangeCulture(CultureInfo.GetCultureInfo(lang));
            }
        }

        private void Window_PreviewDragOver_1(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.None;

            if (e.Data.GetData(DataFormats.FileDrop) != null)
            {
                string[] dirs = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (dirs != null &&
                    dirs.Length == 1 &&
                    System.IO.Directory.Exists(dirs[0]))
                {
                    e.Effects = DragDropEffects.Copy;
                }
            }

            e.Handled = true;
        }

        private void Window_Drop_1(object sender, DragEventArgs e)
        {
            string[] dirs = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (dirs != null)
            {
                _targetFolder.FolderPath = dirs[0];
            }
        }

        private void _menuAbout_Click_1(object sender, RoutedEventArgs e)
        {
            var dialog = new Common.Views.AboutDialog();
            dialog.ShowDialog();
        }
    }
}
