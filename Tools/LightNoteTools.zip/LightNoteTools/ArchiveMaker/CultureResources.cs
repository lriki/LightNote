﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Data;

/*
 *  CultureResources の使い方
 *      http://d.hatena.ne.jp/akiramei/20081021
 *      http://yohshiy.blog.fc2.com/blog-entry-232.html
 *  
 *  ○準備・XAMLからの参照
 *      以下のXAMLを、ウィンドウアプリであれば App.xaml、
 *      コントロールライブラリであれば各コントロールの <xxxx.Resource> に記述する。
 *          <ResourceDictionary>
 *               <ObjectDataProvider x:Key="【各XAMLからアクセスする名前(※1)】" 
 *                                   ObjectType="{x:Type 【CultureResourcesのある名前空間】:CultureResources}" 
 *                                   MethodName="GetResourceInstance"/>
 *          </ResourceDictionary>
 *     
 *      あとは以下のように参照する。
 *          <Label Content="{Binding Path=【文字列ID】, Source={StaticResource 【各XAMLからアクセスする名前】}}" 
 *      
 *      (※1)【各XAMLからアクセスする名前】は CultureResources.ResourceKeyName に定義している。
 *            上記 XAML の方はこれに合わせておくこと。別の名前にしたい場合は↓のも変更する。
 *            このキー名が一致しないと例外が発生する。
 *            
 *  ○言語を変更する
 *      次の一文のように書くだけでOK。
 *          CultureResources.ChangeCulture(CultureInfo.GetCultureInfo("en-US"));
 *          
 * 
 *  ○注意点
 *      CultureResources はアセンブリ単位で個別に持つ必要がある。
 *      そのため、言語を変更する場合は全ての CultureResources の ChangeCulture() を呼ぶ必要がある。
 *  
 *  ○その他
 *      ・カルチャごとのリソースは、Resources ファイル名に .ja-JP 等を付けるだけでOK。
 *        あとはフレームワークが取り計らってくれる。
 * 
 *      ・デフォルトのカルチャは、システムの設定による。
 *        コントロールパネルから変更可能だが、Ultimate のみ可能。 
 * 
 *      ・正常に作成できれば、bin フォルダに ja-JP 等のフォルダが出来上がって、dllが入っているはず。
 */

namespace ArchiveMaker
{
    public class CultureResources
    {
        const string ResourceKeyName = "StrRes";
        static readonly List<CultureInfo> cultures = new List<CultureInfo>();

        // スタティックコンストラクタ (最初にこれが呼ばれる)
        static CultureResources()
        {
            // 言語の選択候補として日本語(日本)と英語(米国)を追加する
            cultures.Add(CultureInfo.GetCultureInfo("en-US"));
            cultures.Add(CultureInfo.GetCultureInfo("ja-JP"));
        }

        public static IList<CultureInfo> Cultures
        {
            get { return cultures; }
        }

        public Properties.Resources GetResourceInstance()
        {
            // resxファイルから自動生成されたクラスのインスタンスを返す
            return new Properties.Resources();
        }

        private static ObjectDataProvider provider;
        public static ObjectDataProvider ResourceProvider
        {
            get
            {
                // キー「ResourcesInstance」はApp.xaml内で定義している
                if (provider == null && System.Windows.Application.Current != null)
                    provider = (ObjectDataProvider)System.Windows.Application.Current.FindResource(ResourceKeyName);
                return provider;
            }
        }

        public static void ChangeCulture(CultureInfo culture)
        {
            // 言語の切り替えメソッド
            Properties.Resources.Culture = culture;
            ResourceProvider.Refresh();
        }
    }
}
